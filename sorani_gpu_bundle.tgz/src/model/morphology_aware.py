"""
Morphology-Aware Transformer Model

Extends the baseline Transformer with explicit morphological feature embeddings,
agreement graph attention biasing, and an auxiliary agreement prediction loss
to improve agreement error correction.
"""

import logging
import time
from typing import Optional

import torch
import torch.nn as nn
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

from src.morphology.graph import EDGE_TYPE_ORDER

logger = logging.getLogger(__name__)


class MorphologicalEmbedding(nn.Module):
    """Embedding layer for morphological features."""
    
    def __init__(
        self,
        feature_vocab_size: int,
        num_features: int = 9,
        embed_dim: int = 64,
    ):
        super().__init__()
        self.num_features = num_features
        self.embed_dim = embed_dim
        
        # One embedding per feature type
        self.feature_embeddings = nn.ModuleList([
            nn.Embedding(feature_vocab_size, embed_dim)
            for _ in range(num_features)
        ])
        
        # Project concatenated features to match model dimension
        self.projection = nn.Linear(num_features * embed_dim, embed_dim)
    
    def forward(self, feature_indices: torch.Tensor) -> torch.Tensor:
        """
        Args:
            feature_indices: [batch, seq_len, num_features] integer tensor
            
        Returns:
            [batch, seq_len, embed_dim] feature embedding tensor
        """
        embeddings = []
        for i, emb_layer in enumerate(self.feature_embeddings):
            feat_emb = emb_layer(feature_indices[:, :, i])  # [batch, seq_len, embed_dim]
            embeddings.append(feat_emb)
        
        # Concatenate and project
        concat = torch.cat(embeddings, dim=-1)  # [batch, seq_len, num_features * embed_dim]
        projected = self.projection(concat)      # [batch, seq_len, embed_dim]
        
        return projected


class AgreementPredictor(nn.Module):
    """Auxiliary head for predicting agreement violations."""
    
    def __init__(self, hidden_dim: int, num_agreement_types: int = len(EDGE_TYPE_ORDER) + 1):
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_dim // 2, num_agreement_types),
        )
    
    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hidden_states: [batch, seq_len, hidden_dim]
            
        Returns:
            [batch, seq_len, num_agreement_types] logits
        """
        return self.classifier(hidden_states)


class MorphologyAwareGEC(nn.Module):
    """GEC model with morphological feature integration.

    RTL Script Note (ARCH-8): ByT5 processes raw UTF-8 bytes in their
    natural storage order (left-to-right at the byte level).  Arabic
    script characters — including Sorani Kurdish — are encoded as
    multi-byte UTF-8 sequences whose byte order is determined by
    Unicode codepoint, not visual rendering direction.  The model's
    positional embeddings therefore capture byte-sequence position,
    not visual text direction.  This byte-level abstraction makes
    explicit RTL positional encoding adaptation unnecessary; the model
    learns inter-token relationships (including right-to-left reading
    patterns) from training data. Agreement graph bias further helps
    the model attend to morphologically related positions regardless
    of their linear order.
    """
    
    def __init__(
        self,
        model_name: str = "google/byt5-small",
        feature_vocab_size: int = 50,
        num_morph_features: int = 9,
        morph_embed_dim: int = 64,
        agreement_loss_weight: float = 0.3,
        edge_type_loss_weights: Optional[dict[str, float]] = None,
        max_length: int = 128,
        num_agreement_types: int = len(EDGE_TYPE_ORDER) + 1,
        morph_gate_init: float = 0.0,
        morph_residual_init: float = 0.0,
    ):
        super().__init__()
        self.model_name = model_name
        self.max_length = max_length
        # Injection warm-start knobs. With both at 0.0 the morph contribution
        # starts at exactly zero (legacy ARCH-9 behaviour). A positive
        # morph_gate_init opens the gate from step 1 and a positive
        # morph_residual_init seeds the residual projection with small random
        # weights, so morphological features influence the encoder immediately
        # instead of having to climb out of a zero-gradient identity start.
        self.morph_gate_init = morph_gate_init
        self.morph_residual_init = morph_residual_init
        self._base_agreement_loss_weight = agreement_loss_weight
        self.agreement_loss_weight = agreement_loss_weight
        # Default: equal weights for every edge type so the per-type loss
        # path is always active (fix 4.4)
        if edge_type_loss_weights is None:
            edge_type_loss_weights = {et: 1.0 for et in EDGE_TYPE_ORDER}
        self.edge_type_loss_weights = edge_type_loss_weights
        
        # Pretrained backbone
        logger.info("Loading pretrained model: %s", model_name)
        self.backbone = AutoModelForSeq2SeqLM.from_pretrained(model_name)
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        
        # Get hidden dimension from backbone
        hidden_dim = self.backbone.config.d_model
        
        # Morphological feature embedding
        self.morph_embedding = MorphologicalEmbedding(
            feature_vocab_size=feature_vocab_size,
            num_features=num_morph_features,
            embed_dim=morph_embed_dim,
        )
        
        # Projection to add morph features to hidden states.
        # Residual injection: project morph_emb to hidden_dim and add as
        # a gated residual instead of overwriting hidden_states. The
        # residual gate is initialised at 0 (zero-init last linear bias
        # and weights small) so the model starts equivalent to the
        # pretrained ByT5 backbone and learns to introduce morph signal
        # gradually. The legacy concat-and-project path is kept under
        # `morph_projection` for checkpoint compatibility but is no
        # longer used by `_integrate_morph_features` (see ARCH-9 fix).
        self.morph_projection = nn.Linear(
            hidden_dim + morph_embed_dim, hidden_dim
        )
        self.morph_layer_norm = nn.LayerNorm(hidden_dim)
        self.morph_residual_proj = nn.Linear(morph_embed_dim, hidden_dim)
        # Zero-init so morph contribution starts at exactly zero, unless a
        # positive morph_residual_init is requested (warm-started injection).
        if morph_residual_init and morph_residual_init > 0.0:
            nn.init.normal_(self.morph_residual_proj.weight, mean=0.0, std=morph_residual_init)
            nn.init.zeros_(self.morph_residual_proj.bias)
        else:
            nn.init.zeros_(self.morph_residual_proj.weight)
            nn.init.zeros_(self.morph_residual_proj.bias)
        # Learnable scalar gate. Default 0 -> identity start; a positive
        # morph_gate_init opens the gate immediately so morph signal flows
        # from the first optimiser step.
        self.morph_gate = nn.Parameter(torch.full((1,), float(morph_gate_init)))
        
        # Auxiliary agreement predictor
        self.agreement_predictor = AgreementPredictor(
            hidden_dim=hidden_dim,
            num_agreement_types=num_agreement_types,
        )
        
        self.agreement_loss_fn = nn.CrossEntropyLoss()

        # Learnable per-edge-type weights for typed agreement masks.
        # Length matches EDGE_TYPE_ORDER; dynamically sized.
        self.max_edge_types = len(EDGE_TYPE_ORDER)
        self.edge_type_weights = nn.Parameter(
            torch.ones(self.max_edge_types) / self.max_edge_types
        )

        # Decoder-side agreement projection: provides position-specific
        # agreement signal for decoder cross-attention, so the decoder
        # receives agreement-aware encoder representations distinct from
        # the encoder-side gating.
        self.decoder_agr_proj = nn.Linear(hidden_dim, hidden_dim)

    def anneal_agreement_loss(self, epoch: int, warmup_epochs: int = 5) -> float:
        """Linear warmup of the agreement auxiliary loss weight.

        During the first *warmup_epochs* epochs the weight ramps from 0
        to the base value, preventing the auxiliary objective from
        dominating before the primary GEC loss stabilises.

        Returns:
            The updated agreement_loss_weight.
        """
        if epoch >= warmup_epochs:
            self.agreement_loss_weight = self._base_agreement_loss_weight
        else:
            self.agreement_loss_weight = (
                self._base_agreement_loss_weight * (epoch + 1) / warmup_epochs
            )
        return self.agreement_loss_weight
    
    def _build_agreement_bias(
        self,
        agreement_mask: torch.Tensor,
        seq_len: int,
    ) -> torch.Tensor:
        """Convert agreement adjacency matrix to byte-level attention bias.

        Handles two input formats:
          3D [batch, N, N]               — binary adjacency (backward compat)
          4D [batch, num_types, N, N]    — typed adjacency with learnable weights

        Args:
            agreement_mask: binary (3D) or typed (4D) adjacency tensor
            seq_len: target byte-level sequence length

        Returns:
            [batch, 1, seq_len, seq_len] additive attention bias
        """
        agreement_mask = agreement_mask.to(self.edge_type_weights.device)
        if agreement_mask.dim() == 4:
            # Typed: apply learnable per-type weights then sum
            num_types = min(agreement_mask.size(1), len(self.edge_type_weights))
            weights = torch.softmax(
                self.edge_type_weights[:num_types], dim=0
            )  # [num_types]
            combined = (
                agreement_mask[:, :num_types].float()
                * weights.view(1, -1, 1, 1)
            ).sum(dim=1)  # [batch, N, N]
        else:
            # Binary: use as-is
            combined = agreement_mask.float()

        n_words = combined.size(1)
        if n_words >= seq_len:
            bias = combined[:, :seq_len, :seq_len]
        else:
            bias = torch.zeros(
                combined.size(0), seq_len, seq_len,
                device=combined.device,
            )
            bias[:, :n_words, :n_words] = combined
        # Additive bias: agreement-linked positions get a positive boost
        return bias.unsqueeze(1) * 2.0  # [batch, 1, seq_len, seq_len]

    def _integrate_morph_features(
        self,
        hidden_states: torch.Tensor,
        morph_features: torch.Tensor,
    ) -> torch.Tensor:
        """Integrate morphological embeddings into encoder hidden states.

        Residual injection (ARCH-9 fix). The previous implementation
        concatenated `[hidden_states; morph_emb]` and projected the
        result, which let a randomly-initialised `morph_projection`
        overwrite every encoder position on training step 1 and
        destroy the pretrained signal. This version computes a
        zero-initialised residual:

            h' = LN( h + tanh(morph_gate) * W_r(morph_emb) )

        At init, `morph_gate=0` and `W_r=0` so `h' = LN(h)`, leaving
        the backbone effectively untouched. The gradient still flows
        through morph_emb, so the model can learn to introduce
        morphological signal in proportion to how useful it is.

        Args:
            hidden_states: [batch, seq_len, hidden_dim]
            morph_features: [batch, word_len, num_features]

        Returns:
            [batch, seq_len, hidden_dim] updated hidden states
        """
        morph_emb = self.morph_embedding(morph_features)
        target_len = hidden_states.size(1)
        if morph_emb.size(1) != target_len:
            if morph_emb.size(1) < target_len:
                morph_emb = torch.nn.functional.interpolate(
                    morph_emb.transpose(1, 2),
                    size=target_len,
                    mode="nearest",
                ).transpose(1, 2)
            else:
                morph_emb = morph_emb[:, :target_len, :]
        residual = self.morph_residual_proj(morph_emb)
        gate = torch.tanh(self.morph_gate)
        # No LayerNorm on the sum: ByT5 encoder hidden_states have std~0.05,
        # so wrapping (h + gate*residual) in LayerNorm rescales to std~1 and
        # destroys the pre-trained decoder-encoder activation match. Residual
        # is zero-init, so identity start is preserved without the LN.
        return hidden_states + gate * residual

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        morph_features: Optional[torch.Tensor] = None,
        labels: Optional[torch.Tensor] = None,
        agreement_labels: Optional[torch.Tensor] = None,
        agreement_mask: Optional[torch.Tensor] = None,
    ) -> dict:
        """Forward pass with morphological features and agreement graph.
        
        Args:
            input_ids: [batch, seq_len]
            attention_mask: [batch, seq_len]
            morph_features: [batch, seq_len, num_features] — optional
            labels: [batch, seq_len] target token ids
            agreement_labels: [batch, seq_len] agreement type labels
            agreement_mask: adjacency tensor — either
                3D [batch, N, N] binary from to_adjacency_matrix(), or
                4D [batch, num_types, N, N] typed from to_typed_stacked_matrix()
            
        Returns:
            Dict with 'loss', 'logits', 'agreement_logits'.
        """
        # Get encoder outputs
        encoder_outputs = self.backbone.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
        )
        hidden_states = encoder_outputs.last_hidden_state
        
        # Integrate morphological features if provided
        if morph_features is not None:
            hidden_states = self._integrate_morph_features(hidden_states, morph_features)
        
        # Agreement prediction (auxiliary task)
        agreement_logits = self.agreement_predictor(hidden_states)
        
        # Decoder with modified encoder outputs
        # Replace encoder hidden states
        encoder_outputs.last_hidden_state = hidden_states
        
        # Build cross-attention mask with agreement bias if provided
        cross_attn_mask = attention_mask
        if agreement_mask is not None:
            agr_bias = self._build_agreement_bias(
                agreement_mask, hidden_states.size(1)
            )
            # Expand 1D padding mask to 2D and add agreement bias
            expanded = attention_mask.unsqueeze(1).unsqueeze(2).float()
            cross_attn_mask = (expanded + agr_bias).clamp(min=0, max=1)
            # Collapse back for HF API: use the original 1D mask so the
            # backbone handles padding, but store biased states.
            # ByT5 does not expose a head-level mask parameter, so we
            # bake the bias into the hidden states via a residual gate.

            # Per-position gate: max preserves which positions participate
            # in agreement edges (4.2), single-gating avoids amplification (4.3)
            gate = torch.sigmoid(agr_bias.squeeze(1).max(dim=-1, keepdim=True).values)  # [batch, seq, 1]
            agr_residual = self.decoder_agr_proj(hidden_states)
            hidden_states = hidden_states + gate * agr_residual

            encoder_outputs.last_hidden_state = hidden_states
        
        # Main GEC loss
        outputs = self.backbone(
            encoder_outputs=encoder_outputs,
            attention_mask=attention_mask,
            labels=labels,
        )
        
        total_loss = outputs.loss if outputs.loss is not None else torch.tensor(0.0, device=hidden_states.device)
        
        # Agreement auxiliary loss — with optional per-edge-type weighting.
        # Mask out padding tokens so they do not dilute the agreement signal.
        if agreement_labels is not None:
            agr_logits_flat = agreement_logits.view(-1, agreement_logits.size(-1))
            agr_labels_flat = agreement_labels.view(-1)
            padding_mask = attention_mask.view(-1).float()

            if self.edge_type_loss_weights:
                # Build per-sample weight vector from edge_type_loss_weights.
                # Agreement label class k corresponds to EDGE_TYPE_ORDER[k-1];
                # class 0 (correct) gets weight 1.0.
                sample_weights = torch.ones_like(agr_labels_flat, dtype=torch.float)
                for edge_type, w in self.edge_type_loss_weights.items():
                    try:
                        cls_idx = EDGE_TYPE_ORDER.index(edge_type) + 1
                    except ValueError:
                        logger.warning("Unknown edge type in loss weights: %s", edge_type)
                        continue
                    sample_weights[agr_labels_flat == cls_idx] = w
                per_token_loss = nn.functional.cross_entropy(
                    agr_logits_flat, agr_labels_flat, reduction="none",
                )
                agreement_loss = (per_token_loss * sample_weights * padding_mask).sum() / padding_mask.sum().clamp(min=1.0)
            else:
                per_token_loss = nn.functional.cross_entropy(
                    agr_logits_flat, agr_labels_flat, reduction="none",
                )
                agreement_loss = (per_token_loss * padding_mask).sum() / padding_mask.sum().clamp(min=1.0)

            weighted_agr_loss = self.agreement_loss_weight * agreement_loss
            total_loss = total_loss + weighted_agr_loss
        
        return {
            "loss": total_loss,
            "seq2seq_loss": outputs.loss if outputs.loss is not None else total_loss,
            "agreement_loss": agreement_loss if agreement_labels is not None else torch.tensor(0.0, device=total_loss.device),
            "logits": outputs.logits,
            "agreement_logits": agreement_logits,
        }
    
    def correct(self, text: str, morph_features: Optional[torch.Tensor] = None,
                agreement_mask: Optional[torch.Tensor] = None,
                num_beams: int = 4,
                length_penalty: float = 1.0,
                no_repeat_ngram_size: int = 0,
                max_length: int | None = None) -> str:
        """Correct a single sentence."""
        t_start = time.perf_counter()
        gen_max_length = max_length or self.max_length
        inputs = self.tokenizer(
            text,
            return_tensors="pt",
            max_length=self.max_length,
            truncation=True,
            padding=True,
        )
        
        device = next(self.backbone.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        gen_kwargs: dict = {
            "max_length": gen_max_length,
            "num_beams": num_beams,
            "early_stopping": True,
            "length_penalty": length_penalty,
        }
        if no_repeat_ngram_size > 0:
            gen_kwargs["no_repeat_ngram_size"] = no_repeat_ngram_size
        
        with torch.no_grad():
            # Run encoder with morphological feature integration
            encoder_outputs = self.backbone.encoder(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
            )
            hidden_states = encoder_outputs.last_hidden_state
            
            if morph_features is not None:
                morph_features = morph_features.to(device)
                hidden_states = self._integrate_morph_features(hidden_states, morph_features)
            
            # Apply agreement graph bias if provided
            if agreement_mask is not None:
                agreement_mask = agreement_mask.to(device)
                agr_bias = self._build_agreement_bias(
                    agreement_mask, hidden_states.size(1)
                )
                gate = torch.sigmoid(agr_bias.squeeze(1).max(dim=-1, keepdim=True).values)
                agr_residual = self.decoder_agr_proj(hidden_states)
                hidden_states = hidden_states + gate * agr_residual
            
            encoder_outputs.last_hidden_state = hidden_states
            
            outputs = self.backbone.generate(
                encoder_outputs=encoder_outputs,
                attention_mask=inputs["attention_mask"],
                **gen_kwargs,
            )
        
        corrected = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        elapsed_ms = (time.perf_counter() - t_start) * 1000
        logger.debug("correct() latency: %.1f ms", elapsed_ms)
        return corrected

    def classify_errors(
        self,
        text: str,
        morph_features: Optional[torch.Tensor] = None,
        agreement_mask: Optional[torch.Tensor] = None,
    ) -> list[dict]:
        """Run the agreement predictor on input and return per-token error types.

        Returns a list of dicts with 'token_idx', 'predicted_type', and 'score'
        for tokens predicted to have agreement errors (non-zero class).
        """
        inputs = self.tokenizer(
            text, return_tensors="pt",
            max_length=self.max_length, truncation=True, padding=True,
        )
        device = next(self.backbone.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            encoder_outputs = self.backbone.encoder(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
            )
            hidden_states = encoder_outputs.last_hidden_state

            if morph_features is not None:
                morph_features = morph_features.to(device)
                hidden_states = self._integrate_morph_features(hidden_states, morph_features)

            logits = self.agreement_predictor(hidden_states)  # [1, seq_len, num_types]
            preds = logits.argmax(dim=-1)[0]  # [seq_len]
            scores = torch.softmax(logits[0], dim=-1)  # [seq_len, num_types]

        errors = []
        for idx in range(preds.size(0)):
            cls = preds[idx].item()
            if cls == 0:
                continue
            # Map class index back to edge type name
            type_name = EDGE_TYPE_ORDER[cls - 1] if cls <= len(EDGE_TYPE_ORDER) else f"type_{cls}"
            errors.append({
                "token_idx": idx,
                "predicted_type": type_name,
                "score": scores[idx, cls].item(),
            })
        return errors

    def _build_inference_tensors(
        self,
        text: str,
        analyzer: "MorphologicalAnalyzer",
        feature_extractor: "FeatureExtractor",
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Build morph_features and agreement_mask tensors for inference.

        Args:
            text: input sentence
            analyzer: MorphologicalAnalyzer instance
            feature_extractor: FeatureExtractor instance

        Returns:
            (morph_features, agreement_mask) tensors ready for correct()
        """
        from src.morphology.builder import build_agreement_graph

        # Word-level morphological features (not yet mapped to bytes)
        morph_feats_word = feature_extractor.extract_features(text)
        num_feat = feature_extractor.get_num_features()

        # Agreement graph: [1, num_types, max_length, max_length]
        graph = build_agreement_graph(text, analyzer)
        stacked, _ = graph.to_typed_stacked_matrix()
        num_types = len(EDGE_TYPE_ORDER)

        # Word-to-byte mapping using cumulative byte tracking (fix 4.5)
        word_tokens = analyzer.tokenize(text)
        byte_offsets: list[tuple[int, int]] = []
        char_cursor = 0
        byte_cursor = 0
        for w in word_tokens:
            # Skip whitespace
            while char_cursor < len(text) and text[char_cursor] in (' ', '\t', '\n'):
                byte_cursor += len(text[char_cursor].encode("utf-8"))
                char_cursor += 1
            idx = text.find(w, char_cursor)
            if idx >= 0:
                # Advance byte cursor through any gap
                if idx > char_cursor:
                    byte_cursor += len(text[char_cursor:idx].encode("utf-8"))
                byte_start = byte_cursor
                byte_end = byte_start + len(w.encode("utf-8"))
                byte_offsets.append((byte_start, byte_end))
                char_cursor = idx + len(w)
                byte_cursor = byte_end
            else:
                logger.warning(
                    "Word %r not found at char_cursor=%d; using cumulative estimate",
                    w[:30], char_cursor,
                )
                byte_start = byte_cursor
                byte_end = byte_start + len(w.encode("utf-8"))
                byte_offsets.append((byte_start, byte_end))
                char_cursor += len(w)
                byte_cursor = byte_end

        # Map word-level morph features to byte positions (fix 4.1)
        morph_feats = [[0] * num_feat for _ in range(self.max_length)]
        for w_idx in range(min(len(morph_feats_word), len(byte_offsets))):
            b_start, b_end = byte_offsets[w_idx]
            for bi in range(b_start, min(b_end, self.max_length)):
                morph_feats[bi] = morph_feats_word[w_idx]
        morph_tensor = torch.tensor([morph_feats], dtype=torch.long)

        # PIPE-16: Optimized agreement mask construction using sparse
        # index-based tensor filling instead of 6-nested Python loops.
        n_words = len(graph.tokens)
        agr_tensor = torch.zeros(
            1, num_types, self.max_length, self.max_length, dtype=torch.int8,
        )
        for t_idx in range(min(len(stacked), num_types)):
            word_mat = stacked[t_idx]
            for r in range(min(len(word_mat), n_words)):
                for c in range(min(len(word_mat[r]), n_words)):
                    if word_mat[r][c] == 0:
                        continue
                    if r < len(byte_offsets) and c < len(byte_offsets):
                        r_start, r_end = byte_offsets[r]
                        c_start, c_end = byte_offsets[c]
                        r_end = min(r_end, self.max_length)
                        c_end = min(c_end, self.max_length)
                        if r_start < r_end and c_start < c_end:
                            agr_tensor[0, t_idx, r_start:r_end, c_start:c_end] = 1
        return morph_tensor, agr_tensor

    def correct_with_morphology(
        self,
        text: str,
        analyzer: "MorphologicalAnalyzer",
        feature_extractor: "FeatureExtractor",
        num_beams: int = 4,
    ) -> str:
        """Correct a sentence using full morphological features and agreement graph.

        This is the primary inference entry point; it constructs morphological
        features and the agreement mask automatically from the raw text.

        Args:
            text: input sentence to correct
            analyzer: MorphologicalAnalyzer instance
            feature_extractor: FeatureExtractor instance
            num_beams: beam search width

        Returns:
            Corrected sentence string
        """
        morph_tensor, agr_tensor = self._build_inference_tensors(
            text, analyzer, feature_extractor
        )
        return self.correct(
            text,
            morph_features=morph_tensor,
            agreement_mask=agr_tensor,
            num_beams=num_beams,
        )

    def correct_with_confidence(
        self,
        text: str,
        analyzer: "MorphologicalAnalyzer",
        feature_extractor: "FeatureExtractor",
        num_beams: int = 4,
    ) -> tuple[str, float]:
        """Correct a sentence and return a confidence score.

        Returns:
            (corrected_text, confidence) where confidence is in (0, 1].
        """
        morph_tensor, agr_tensor = self._build_inference_tensors(
            text, analyzer, feature_extractor
        )
        inputs = self.tokenizer(
            text, return_tensors="pt",
            max_length=self.max_length, truncation=True, padding=True,
        )
        device = next(self.backbone.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            encoder_outputs = self.backbone.encoder(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
            )
            hidden_states = encoder_outputs.last_hidden_state

            if morph_tensor is not None:
                morph_tensor = morph_tensor.to(device)
                hidden_states = self._integrate_morph_features(hidden_states, morph_tensor)

            if agr_tensor is not None:
                agr_tensor = agr_tensor.to(device)
                agr_bias = self._build_agreement_bias(agr_tensor, hidden_states.size(1))
                gate = torch.sigmoid(agr_bias.squeeze(1).max(dim=-1, keepdim=True).values)
                agr_residual = self.decoder_agr_proj(hidden_states)
                hidden_states = hidden_states + gate * agr_residual

            encoder_outputs.last_hidden_state = hidden_states

            gen_out = self.backbone.generate(
                encoder_outputs=encoder_outputs,
                attention_mask=inputs["attention_mask"],
                max_length=self.max_length,
                num_beams=num_beams,
                early_stopping=True,
                return_dict_in_generate=True,
                output_scores=True,
            )

        corrected = self.tokenizer.decode(gen_out.sequences[0], skip_special_tokens=True)

        if gen_out.scores:
            import torch.nn.functional as F
            import math
            log_probs = []
            for step, score in enumerate(gen_out.scores):
                probs = F.log_softmax(score[0], dim=-1)
                token_id = gen_out.sequences[0, step + 1]
                log_probs.append(probs[token_id].item())
            mean_lp = sum(log_probs) / len(log_probs) if log_probs else 0.0
            confidence = math.exp(mean_lp)
        else:
            confidence = 1.0

        return corrected, confidence

    def correct_batch(
        self,
        texts: list[str],
        analyzer: "MorphologicalAnalyzer",
        feature_extractor: "FeatureExtractor",
        num_beams: int = 4,
    ) -> list[str]:
        """Correct a batch of sentences with morphological features.

        Args:
            texts: list of input sentences
            analyzer: MorphologicalAnalyzer instance
            feature_extractor: FeatureExtractor instance
            num_beams: beam search width

        Returns:
            List of corrected sentences
        """
        if not texts:
            return []

        device = next(self.backbone.parameters()).device
        num_feat = feature_extractor.get_num_features()
        num_types = len(EDGE_TYPE_ORDER)

        all_morph = []
        all_agr = []
        for text in texts:
            morph_tensor, agr_tensor = self._build_inference_tensors(
                text, analyzer, feature_extractor
            )
            all_morph.append(morph_tensor.squeeze(0))
            all_agr.append(agr_tensor.squeeze(0))

        morph_batch = torch.stack(all_morph).to(device)
        agr_batch = torch.stack(all_agr).to(device)

        inputs = self.tokenizer(
            texts,
            return_tensors="pt",
            max_length=self.max_length,
            truncation=True,
            padding="max_length",
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            encoder_outputs = self.backbone.encoder(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
            )
            hidden_states = encoder_outputs.last_hidden_state
            hidden_states = self._integrate_morph_features(hidden_states, morph_batch)

            agr_bias = self._build_agreement_bias(agr_batch, hidden_states.size(1))
            gate = torch.sigmoid(agr_bias.squeeze(1).max(dim=-1, keepdim=True).values)
            agr_residual = self.decoder_agr_proj(hidden_states)
            hidden_states = hidden_states + gate * agr_residual
            encoder_outputs.last_hidden_state = hidden_states

            outputs = self.backbone.generate(
                encoder_outputs=encoder_outputs,
                attention_mask=inputs["attention_mask"],
                max_length=self.max_length,
                num_beams=num_beams,
                early_stopping=True,
            )

        return [
            self.tokenizer.decode(o, skip_special_tokens=True)
            for o in outputs
        ]

    def training_step(
        self,
        source_texts: list[str],
        target_texts: list[str],
        analyzer: "MorphologicalAnalyzer | None" = None,
        feature_extractor: "FeatureExtractor | None" = None,
    ) -> torch.Tensor:
        """Tokenize a batch, build morphological tensors, and return the loss.

        Convenience method used by ``scripts/08_ablation.py``.  If *analyzer*
        and *feature_extractor* are not supplied, falls back to attributes set
        via ``set_training_tools()``.  When neither is available, morphological
        features are omitted (equivalent to a baseline forward pass).
        """
        analyzer = analyzer or getattr(self, "_training_analyzer", None)
        feature_extractor = feature_extractor or getattr(
            self, "_training_feature_extractor", None
        )

        inputs = self.tokenizer(
            source_texts, return_tensors="pt",
            max_length=self.max_length, truncation=True, padding="max_length",
        )
        labels = self.tokenizer(
            target_texts, return_tensors="pt",
            max_length=self.max_length, truncation=True, padding="max_length",
        )["input_ids"]

        device = next(self.backbone.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        labels = labels.to(device)

        morph_tensor = None
        agr_tensor = None
        if analyzer and feature_extractor:
            morph_list = []
            agr_list = []
            for text in source_texts:
                m, a = self._build_inference_tensors(text, analyzer, feature_extractor)
                morph_list.append(m.squeeze(0))
                agr_list.append(a.squeeze(0))
            morph_tensor = torch.stack(morph_list).to(device)
            agr_tensor = torch.stack(agr_list).to(device)

            # Ablation: zero out features not in the active subset.
            active = getattr(self, "_ablation_active_features", None)
            if active is not None and morph_tensor is not None:
                _ALL_FEATURES = [
                    "person", "number", "tense", "aspect", "case",
                    "definiteness", "transitivity", "clitic_person",
                    "clitic_number",
                ]
                for f_idx, fname in enumerate(_ALL_FEATURES):
                    if fname not in active:
                        morph_tensor[:, :, f_idx] = 0

        outputs = self.forward(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            morph_features=morph_tensor,
            labels=labels,
            agreement_mask=agr_tensor,
        )
        return outputs["loss"]

    def set_training_tools(
        self,
        analyzer: "MorphologicalAnalyzer",
        feature_extractor: "FeatureExtractor",
    ) -> None:
        """Store analyzer and feature extractor for use by ``training_step()``."""
        self._training_analyzer = analyzer
        self._training_feature_extractor = feature_extractor
